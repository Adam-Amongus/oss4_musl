<?php
	include "version.php";
	include "defaults.php";
	include "functions.php";
?>
