<?php

define("PHPMAKE_VERSION", "0.1");

?>
