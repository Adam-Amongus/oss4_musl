?package(oss-linux):needs="X11" \
  section="Apps/Sound" \
  title="ossxmix" \
  command="/usr/bin/ossxmix"
