#ifndef OSSPLAY_PARSER_H
#define OSSPLAY_PARSER_H

#include "ossplay.h"

errors_t play_file (dspdev_t *, const char *, dlopen_funcs_t **);

#endif
